替换到
C:\Users\admin\AppData\Local\Packages\OpenAI.Codex_2p2nqsd0c76g0\LocalCache\Roaming\Codex\Local Storage\leveldb

%localappdata%\Packages\OpenAI.Codex_2p2nqsd0c76g0\LocalCache\Roaming\Codex\Local Storage\leveldb
